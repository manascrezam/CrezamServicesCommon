import os
from datetime import datetime, timedelta, timezone
from azure.storage.blob import BlobServiceClient, generate_blob_sas, BlobSasPermissions
from dotenv import load_dotenv
import requests
from utils import run_as_async

load_dotenv()

class AzureBlobStorage:
    def __init__(self, account_name=None, account_key=None):
        self.account_name = account_name or os.getenv('AZURE_ACC_NAME')
        self.account_key = account_key or os.getenv('AZURE_ACC_KEY')
        self.service_client = BlobServiceClient(
            account_url=f"https://{self.account_name}.blob.core.windows.net",
            credential=self.account_key
        )

    def _generate_sas_url(self, container, blob_name, expiry_days=365):
        sas_token = generate_blob_sas(
            account_name=self.account_name,
            container_name=container,
            blob_name=blob_name,
            account_key=self.account_key,
            permission=BlobSasPermissions(read=True),
            expiry=datetime.utcnow() + timedelta(days=expiry_days)
        )
        return f"https://{self.account_name}.blob.core.windows.net/{container}/{blob_name}?{sas_token}"

    def upload(self, file_path, container, blob_name=None, expiry_days=36500):
        try:
            if not blob_name:
                base, ext = os.path.splitext(os.path.basename(file_path))
                timestamp = datetime.now(timezone.utc).isoformat(timespec="seconds").replace(":", "-")
                timestamp = timestamp.split("+")[0]
                blob_name = f"{base}_{timestamp}{ext}"
            container_client = self.service_client.get_container_client(container)
            try:
                container_client.get_container_properties()
            except Exception as e:
                if "ContainerNotFound" in str(e):
                    container_client.create_container()
                else:
                    raise
            with open(file_path, "rb") as data:
                blob_client = container_client.get_blob_client(blob_name)
                blob_client.upload_blob(data, overwrite=True)
            return self._generate_sas_url(container, blob_name, expiry_days)
        except Exception as e:
            print(f"Upload error: {e}")
            return None

    def delete(self, blob_url):
        try:
            path = blob_url.replace(f"https://{self.account_name}.blob.core.windows.net/", "")
            container, blob_name = path.split('/', 1)[0], path.split('?', 1)[0].split('/', 1)[1]
            container_client = self.service_client.get_container_client(container)
            blob_client = container_client.get_blob_client(blob_name)
            blob_client.delete_blob()
            return True
        except Exception as e:
            print(f"Delete error: {e}")
            return False
        
    def save_blob_to_file(self, blob_url):
        filename = os.path.basename(blob_url)
        output_path = os.path.join('static', filename)
        response = requests.get(blob_url, stream=True)
        if response.status_code == 200:
            with open(output_path, 'wb') as file:
                for chunk in response.iter_content(chunk_size=8192):
                    file.write(chunk)
            return output_path
        return None    


class AzureBlobStorageAsync():
    def __init__(self):
        self.blobstorage = AzureBlobStorage()

    async def upload(self, file_path, container, blob_name=None, expiry_days=36500):
        return await run_as_async(
            self.blobstorage.upload,
            file_path,
            container,
            blob_name=blob_name,
            expiry_days=expiry_days
        )

    async def delete(self, container, blob_name):
        return await run_as_async(
            self.blobstorage.delete,
            container,
            blob_name
        )

    async def download(self, container, blob_name, destination_path):
        return await run_as_async(
            self.blobstorage.download,
            container,
            blob_name,
            destination_path
        )
    
    async def save_blob_to_file(self, blob_url):
        return await run_as_async(
            self.blobstorage.save_blob_to_file,
            blob_url,
        )

azure_blob_storage = AzureBlobStorageAsync()