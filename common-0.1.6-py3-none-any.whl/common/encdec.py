import base64
import hashlib
import json
import os
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives import padding
from cryptography.hazmat.backends import default_backend

class EncryptionDelegate:

    @classmethod
    def _get_credentials(cls):
        return (os.environ.get('CZM_ENCKEY'), os.environ.get('CZM_IVKEY'))

    @staticmethod
    def _generate_key(key):
        digest = hashlib.sha256(key.encode()).digest()
        return digest

    @staticmethod
    def encrypt(text, use_sha_key=True, escape_slash=True):
        key,iv = EncryptionDelegate._get_credentials()
        key = EncryptionDelegate._generate_key(key) if use_sha_key else key.encode()
        iv = iv.encode()
        cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
        encryptor = cipher.encryptor()
        
        padder = padding.PKCS7(algorithms.AES.block_size).padder()
        padded_data = padder.update(text.encode()) + padder.finalize()
        
        encrypted = encryptor.update(padded_data) + encryptor.finalize()
        b64 = base64.b64encode(encrypted).decode()
        
        if escape_slash:
            b64 = b64.replace("/", "%2F")
        
        return b64

    @staticmethod
    def decrypt(encrypted_message, use_sha_key=True, escape_slash=True):
        try:
            if escape_slash:
                encrypted_message = encrypted_message.replace("%2F", "/")
            
            key = EncryptionDelegate._generate_key(EncryptionDelegate.ENCKEY) if use_sha_key else EncryptionDelegate.ENCKEY.encode()
            iv = EncryptionDelegate.IVKEY.encode()
            cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
            decryptor = cipher.decryptor()
            
            encrypted_bytes = base64.b64decode(encrypted_message)
            decrypted_padded = decryptor.update(encrypted_bytes) + decryptor.finalize()
            
            unpadder = padding.PKCS7(algorithms.AES.block_size).unpadder()
            decrypted = unpadder.update(decrypted_padded) + unpadder.finalize()
            
            text = decrypted.decode()
            return text
        except Exception as e:
            print(e)
            return None
        
    @staticmethod
    def encrypt_request_body(body):
        keystr = os.environ.get('CZM_KEYSTR')
        key = EncryptionDelegate.encrypt(keystr)
        if isinstance(body, str):
            body = {key: EncryptionDelegate.encrypt(body)}
        else:
            body = {key: EncryptionDelegate.encrypt(json.dumps(body))}
        return json.dumps(body)
    
    @staticmethod
    def decrypt_response_body(res):
        keystr = os.environ.get('CZM_KEYSTR')
        key = EncryptionDelegate.encrypt(keystr)
        if isinstance(res, str):
            res = json.loads(res)
        if key in res:
            decval = EncryptionDelegate.decrypt(res[key])
            if decval is None:
                return None
            try:
                casted_val = json.loads(decval)
            except json.JSONDecodeError:
                casted_val = decval
            return casted_val
        else:
            return res
    
    @staticmethod
    def is_body_encrypted(body):
        keystr = os.environ.get('CZM_KEYSTR')
        key = EncryptionDelegate.encrypt(keystr)
        if key in body:
            return True
        return False