import asyncio
from functools import partial
import os
from fastapi import HTTPException, Request, status
import httpx
from dotenv import load_dotenv
load_dotenv()

def get_subdomain():
    env =  os.environ.get('ENVIRONMENT')
    match env.lower():
        case 'pmprod':
            return 'paramed'
        case 'campusdev':
            return 'dev-campus'
        case 'campusdemo':
            return 'demo-campus'
        case 'vvce':
            return 'vvce'
        case _:
            return 'paramed-dev'

async def run_as_async(sync_func, *args, **kwargs):
    loop = asyncio.get_running_loop()
    fn = partial(sync_func, *args, **kwargs)
    return await loop.run_in_executor(None, fn)

def run_as_sync(async_func, *args, **kwargs):
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    try:
        return loop.run_until_complete(async_func(*args, **kwargs))
    finally:
        loop.close()

async def call_backend_api(endpoint, payload=None, method='POST', headers=None, return_json=True):
    url = f"https://{get_subdomain()}.crezam.com{endpoint}"
    limits = httpx.Limits(max_keepalive_connections=20, max_connections=100)
    timeout = httpx.Timeout(30.0)
    method = method.upper()
    allowed_methods = {'GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'}
    if method not in allowed_methods:
        print(f"[call_backend_api] Unsupported method: {method}")
        return None
    try:
        async with httpx.AsyncClient(limits=limits, timeout=timeout) as client:
            response = await client.request(
                method=method,
                url=url,
                json=payload,
                headers=headers
            )
            response.raise_for_status()
            if return_json:
                return response.json()
            else:
                return response.text
    except httpx.RequestError as e:
       print(f"[call_backend_api] Request failed: {e}")
    except httpx.HTTPStatusError as e:
       print(f"[call_backend_api] HTTP error {e.response.status_code}: {e.response.text}")
    except Exception as e:
       print(f"[call_backend_api] Unexpected error: {e}")
    return None

async def call_ai_bot(bot, payload, timeout=60, caller_service='default'):
    url = f"https://{get_subdomain()}.crezam.com/campus_ai/call"
    full_payload = {
        "user": f"{caller_service}_service",
        "jwt": "no-jwt",
        "uid": -1,
        "function": bot,
        "datamodel": payload
    }
    try:
        limits = httpx.Limits(max_keepalive_connections=20, max_connections=100)
        async with httpx.AsyncClient(limits=limits,timeout=httpx.Timeout(timeout)) as client:
            response = await client.post(url, json=full_payload)
            response.raise_for_status()
            return response.json().get('RESPONSE')
    except httpx.RequestError as e:
        print(f"[call_ai_bot] Request failed with {type(e)}: {repr(e)}")
        return None
    except httpx.HTTPStatusError as e:
        print(f"[call_ai_bot] Bad status: {e.response.status_code}")
        print(e.response.text)
        return None
    
def get_jwt_from_header(request: Request) -> str:
    auth_header = request.headers.get('Authorization')
    if auth_header and auth_header.startswith('Bearer '):
        return auth_header.split(' ')[1]
    raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Unauthorized")

async def download_from_url(url):
    try:
        limits = httpx.Limits(max_keepalive_connections=20, max_connections=100)
        async with httpx.AsyncClient(limits=limits, timeout=httpx.Timeout(30.0)) as client:
            response = await client.get(url)
            response.raise_for_status()
            return response.content
    except httpx.RequestError as e:
        print("Request error:", e)
    except httpx.HTTPStatusError as e:
        print(f"HTTP error {e.response.status_code}:", e.response.text)
    return None

__all__ = [
    'get_subdomain', 
    'run_as_async',
    'run_as_sync',
    'call_backend_api',
    'call_ai_bot',
    'get_jwt_from_header',
    'download_from_url',
]